import pybullet as p
import pybullet_data
import time
import os
import numpy as np
import random
import math
import gymnasium as gym
import quadcopter
from matplotlib import pyplot as plt
from trajqueue import queue
from trajgenerator import trajgenerator 
  



env = gym.make('QuadCopter-v0')
obs = env.reset()

init = obs[1]


###### Quick Trajectory Generator Test #####   

#test = trajgenerator(0, 1, 0, 0, 0, height=False)

# testlist = []
# timeframe = []
# for i in range(len(test)):
#     testlist.append(test.dequeue())
#     timeframe.append(i*1/20)

# print(testlist)
# print(timeframe)

# plt.plot(timeframe, testlist)
# plt.show()


### Main ###

for _ in range(10):

    ## NN (ACTOR - ACTION GENERATOR) ##

    setpoints = np.array([random.uniform(-1,1), random.uniform(-1,1), random.uniform(-1,1)])
    print(setpoints)
    
    ## END OF NN ##


    ## TRAJECTORY GENERATOR ##

    pitchrr = trajgenerator(obs[0], setpoints[0], 0, 0, 0, n=60) # x -> pitch
    rollrr = trajgenerator(obs[1], setpoints[1], 0, 0, 0, n=60) # y -> roll
    thrust = trajgenerator(obs[2], setpoints[2], 0, 0, 0, height=True, n=60)


    # END OF TRAJ. GENERATOR ##
    s_time = time.time()

    for i in range(60):
        #print(f"========== {i}th sub-iteration:\n ==========")
        action = np.array([pitchrr.dequeue(), rollrr.dequeue(), thrust.dequeue()])
        obs, reward, done, _ = env.step(action)
        # print(f"drone pos: x: {obs[0]}, y: {obs[1]}, z: {obs[2]}")
        # rotmatrix = np.reshape([obs[3], obs[4], obs[5],
        #                         obs[6], obs[7],obs[8],
        #                         obs[9], obs[10], obs[11]], (3,3))
        # print(f"drone_ori: \n{rotmatrix}")
        # print(f"drone linear velocity: x: {obs[12]}, y: {obs[13]}, z: {obs[14]}")
        # print(f"drone angular velocity: x: {obs[15]}, y:{obs[16]}, z:{obs[17]}")
        # print(f"attractive force: {[obs[18], obs[19], obs[20]]}")
        # print(f"repulsive force: {[obs[21], obs[22], obs[23]]}")
        # print(done)


        
        if done:
            print("reset")
            env.reset()


