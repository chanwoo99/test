import pybullet as p
import pybullet_data
import time
import os
import numpy as np
import random
import math
import gym
import quadcopter
from matplotlib import pyplot as plt
from trajqueue import queue
from trajgenerator import trajgenerator 
  



env = gym.make('QuadCopter-v0')
obs = env.reset()



# ###### Quick Trajectory Generator Test #####   

# thrust = trajgenerator(0, 1, 0, 0, 0, n=240)


# testlist = []
# timeframe = []
# for i in range(len(thrust)):
#     testlist.append(thrust.dequeue())
#     timeframe.append(i*1/120)

# print(testlist)
# print(timeframe)

# plt.plot(timeframe, testlist)
# plt.show()


### Main ###

for _ in range(1000):


    setpoints = np.array([0, 0, 0])
    #print(setpoints)
    

    obs, reward, done, _ = env.step(setpoints)
    #print(obs[2])   
        
    if done:
        print("reset")
        env.reset()


