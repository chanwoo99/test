from gym.envs.registration import register

register(
    id='QuadCopter-v0',
    entry_point='quadcopter.envs:QuadCopterEnv'
)