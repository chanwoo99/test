import pybullet as p
import pybullet_data
import numpy as np
import os

class Object:
    def __init__(self, client, speed, pos =[0, 0, 1.0], ori = p.getQuaternionFromEuler([0,0,0])):
        self.client = client
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        self.object = p.loadURDF("sphere_small.urdf", pos, globalScaling = 3)
        self.object_pos = p.getBasePositionAndOrientation(self.object) 
        self.speed = speed
        self.balldyninfo = p.getDynamicsInfo(self.object,-1)


    def get_id(self):
        return self.object

    def resetbehavior(self, pos):
        p.resetBasePositionAndOrientation(self.object, pos, p.getQuaternionFromEuler([0,0,0]))

    
    def get_observation(self):
        self.object_pos, _ = p.getBasePositionAndOrientation(self.object) # get orientation and position of drone
        return self.object_pos