import pybullet as p
import pybullet_data
import time
import os
import numpy as np
import random
import math
import gym
import quadcopter
from matplotlib import pyplot as plt
from trajqueue import queue
from trajgenerator import trajgenerator 


from stable_baselines3 import TD3
from stable_baselines3.common.noise import NormalActionNoise, OrnsteinUhlenbeckActionNoise

  
### Environment Preparation ###

env = gym.make('QuadCopter-v0')

n_actions = env.action_space.shape[-1]
action_noise = NormalActionNoise(mean=np.zeros(n_actions), sigma=0.1 * np.ones(n_actions))

model = TD3("MlpPolicy", env, action_noise=action_noise, verbose=1, batch_size=100,device="cpu")
model.learn(total_timesteps=100, log_interval=1)
model.save("test1")
vec_env = model.get_env()

obs = vec_env.reset()[0]

  
### Preset Parameter ###

n_eval = 20 # number of trajectory evaluation steps
n_points = 60 # number of trajectory setpoints  
t_max = 10 # maximum episode steps => 10000 or 20000 recommended

### Main ###

for i in range(t_max):
    print(i)
    ## NN (ACTION GENERATOR) ##

    ## ACTION SELECTION OF RL HERE ##
    
    # The below is for test. REMOVE IT WHEN LEARNING
    setpoints = model.predict(obs)
    print("setpoints: ",setpoints)

    
    
    obs, reward, done,_= vec_env.step(setpoints)
    obs=obs[0]
    ## END OF NN ##


    ## TRAJECTORY GENERATOR ##

    # def trajgenerator(
    # p: current position of drone,
    # dp: given action (displacement),
    # v_d: current velocity of drone,
    # w_d: current angular velocity of drone,
    # angle_d: current angle of drone,
    # g: gravitational acceleration = 9.81,
    # tf: desired total time to reach destination = 2,
    # height: if trajectory is about z-axis = False,
    # n: number of steps of trajectory prediction = 20) 

    # OUTPUT: QUEUE OF N ANGULAR ACCELERATION POINTS OR THRUST
    setpoints=setpoints[0]
    pitchrr = trajgenerator(obs[0], setpoints[0], obs[12], obs[15], obs[24], n=n_points) # x -> pitch
    rollrr = trajgenerator(obs[1], setpoints[1], obs[13], obs[16], obs[25], n=n_points) # y -> roll
    thrust = trajgenerator(obs[2], setpoints[2], obs[14], 0, 0, height=True, n=n_points) # z -> thrust, angle and omega should be 0

    ## SUB-LOOP (Evaluation THRU PYBULLET) ##

    # THE BELOW SHOULD BE ADJUSTED TO MODIFY TOTAL LOOP TIME
    # THEY ARE IN THE "quadcopter_env.py":
    
    # p.setTimeStep(1/60, self.client)
    # time.sleep(1/60)
    
    # FOR EXAMPLE, GIVEN THE STEP TIME OF "1/60" and SUB-LOOP OF "60" STEPS, 
    # THE TOTAL TIME OF SUB-LOOP COMPLETION WILL BE 1s. EVERY NEW ACTION WILL BE GIVEN OUT AFTER 1s.
    # THE RECOMMENDED TOTAL SUB-LOOP TIME IS 1/5 ~ 1/15 (5 Hz ~ 15 Hz), WHICH IS 1/5 or 1/15 of 
    # RESPONSE TIME OF ACTUAL DRONE HARDWARE, WHICH IS APPROXIMATELY 1s   

    # IF EVALUATION STEP IS 20, SIMULATION STEP TIME SHOULD BE 1/100 ~ 1/300 (THEREFORE 1/5 ~ 1/15 s FOR TOTAL SUB-LOOP TIME) 

    s_time = time.time()

    for i in range(n_eval):

        to_drone = np.array([pitchrr.dequeue(), rollrr.dequeue(), thrust.dequeue()])
        #deliver to_drone variable as drone control
       

        # if done:
        #     print("reset")
        #     env.reset()
    print(time.time()-s_time)
# clear connection   
p.disconnect()

print("done!")