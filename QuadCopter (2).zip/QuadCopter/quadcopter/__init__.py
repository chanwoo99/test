import gym
gym.register(
    id='QuadCopter-v0',
    entry_point='quadcopter.envs:QuadCopterEnv'
)