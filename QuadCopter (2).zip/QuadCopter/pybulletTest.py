import pybullet as p
import pybullet_data
import time
import os
import numpy as np
import random
import math

# Setting up Pybullet
path = os.path.join(os.path.expanduser('~'), 'QuadCopter', 'drone.urdf')
client = p.connect(p.GUI)
p.setGravity(0,0,-9.80)
print(pybullet_data.getDataPath())
p.setAdditionalSearchPath(pybullet_data.getDataPath())

# generate debug bar (force)
force1 = p.addUserDebugParameter('Force1', 0, 100, 0)
force2 = p.addUserDebugParameter('Force2', 0, 100, 0)
force3 = p.addUserDebugParameter('Force3', 0, 100, 0)
force4 = p.addUserDebugParameter('Force4', 0, 100, 0)

# Setting up objects

planeID = p.loadURDF("plane.urdf") # set up map

# set up drone
drone = p.loadURDF(path, [1, 1, 1.0], p.getQuaternionFromEuler([0,0,0]))
p.resetBaseVelocity(drone, [0, 0, 0], [0, 0, 0])

dronebaseinfo=p.getDynamicsInfo(drone, -1) # getting dynamics info
dronelinkinfo1 = p.getDynamicsInfo(drone, 0) 
dronelinkinfo2 = p.getDynamicsInfo(drone, 1) 
dronelinkinfo3 = p.getDynamicsInfo(drone, 2) 
dronelinkinfo4 = p.getDynamicsInfo(drone, 3) 

drone_mass = dronebaseinfo[0]+dronelinkinfo1[0]+dronelinkinfo2[0]+dronelinkinfo3[0]+dronelinkinfo4[0]
drone_moi = np.array(dronebaseinfo[2])
#print(drone_moi)

# get drone links info
# _link_name_to_index = {p.getBodyInfo(drone)[0].decode('UTF-8'):-1,}
        
# for _id in range(p.getNumJoints(drone)):
# 	_name = p.getJointInfo(drone, _id)[12].decode('UTF-8')
# 	_link_name_to_index[_name] = _id

#print(_link_name_to_index)


# set up ball
ball = p.loadURDF("sphere_small.urdf", [0, 0, 2.5], globalScaling = 3)
balldyninfo = p.getDynamicsInfo(ball,-1)

pos, ori = p.getBasePositionAndOrientation(drone) # get orientation and position of drone
objpos, objori = p.getBasePositionAndOrientation(ball) # get position of an moving object
rho_obj = np.array(pos) - np.array(objpos)
distance = np.sqrt((pos[0]-objpos[0])**2 + (pos[1]-objpos[1])**2 + (pos[2]-objpos[2])**2)
obj_dir = rho_obj/distance
prev_dir = obj_dir

p.resetBaseVelocity(ball, 2*obj_dir, [0, 0, 0])
angvel_prev = 0
# start simulation

for _ in range(10000):
    # ============== drone ================
    #p.resetBaseVelocity(drone, [0, 0, 0], [2, 0, 0])
    pos, ori = p.getBasePositionAndOrientation(drone) # get orientation and position of drone
    linvel, angvel = p.getBaseVelocity(drone)
    ori_euler = p.getEulerFromQuaternion(ori)
    rotmatrix = np.reshape(np.array(p.getMatrixFromQuaternion(ori)), (3,3)) # rotation of body relative to world
    rotmatrix_vel = np.array([1, np.sin(ori[0])*np.sin(ori[1])/np.cos(ori[1]), np.sin(ori[0])*np.sin(ori[1])/np.cos(ori[1]), 
                              0, np.cos(ori[0]), -np.sin(ori[0]),
                              0, np.sin(ori[0])/np.cos(ori[1]), np.cos(ori[0])/np.cos(ori[1])])
    rotmatrix_vel = np.reshape(rotmatrix_vel, (3,3))
    
    angvel_local = np.matmul(rotmatrix_vel,np.transpose(angvel))
    #print(angvel)
    #print(rotmatrix_vel)
    
    matrix_z = np.array([
        np.cos(ori_euler[2]), -np.sin(ori_euler[2]), 0,
        np.sin(ori_euler[2]), np.cos(ori_euler[2]), 0,
        0, 0, 1
    ])
    matrix_z = np.reshape(matrix_z, (3,3))
    
    matrix_y = np.array([
        np.cos(ori_euler[1]), 0, np.sin(ori_euler[1]),
        0, 1, 0,
        -np.sin(ori_euler[1]), 0, np.cos(ori_euler[1])
    ])
    matrix_y = np.reshape(matrix_y, (3,3))
    
    matrix_x = np.array([
        1, 0, 0,
        0, np.cos(ori_euler[0]), -np.sin(ori_euler[0]),
        0, np.sin(ori_euler[0]), np.cos(ori_euler[0])
    ])
    matrix_x = np.reshape(matrix_x, (3,3))
    
    print(f"Rotation about z: \n{matrix_z}")
    print(f"Rotation about y: \n{matrix_y}")
    print(f"Rotation about x: \n{matrix_x}")
    
    print(f"Combined Rotation: \n{np.matmul(np.matmul(matrix_z, matrix_y), matrix_x)}")

    # print(ori_euler)
    print(f"Rotation Matrix: \n{rotmatrix}")
    #print(np.round(np.matmul(np.linalg.inv(rotmatrix), angvel)))
    #p.addUserDebugLine([0,0,0], np.matmul(np.linalg.inv(rotmatrix), angvel), [1, 0, 0], 1.0, 0.05, drone)
    p.addUserDebugLine(objpos, np.array(objpos)+np.array(prev_dir), [0,0,1], 1.0, 0.05)
    
    angvel_prev = angvel
    
    
    objpos, objori = p.getBasePositionAndOrientation(ball) # get position of an moving object

    rho_obj = np.array(pos) - np.array(objpos)
    distance = np.sqrt((pos[0]-objpos[0])**2 + (pos[1]-objpos[1])**2 + (pos[2]-objpos[2])**2)
    obj_dir = rho_obj/distance
    p.resetBaseVelocity(ball, 2*prev_dir, [0, 0, 0])

    objvel, objangv = p.getBaseVelocity(ball)

    p.applyExternalForce(drone, -1, [0, 0, 9.80*drone_mass], pos, p.WORLD_FRAME)
    p.applyExternalTorque(drone, -1, [0, 0, 0],  p.LINK_FRAME)    
    p.addUserDebugLine(objpos, objvel, [0,0,1], 1.0, 0.05)
    p.addUserDebugLine(objpos, pos, [0,1,0], 1.0, 0.05)
    

    if (abs(pos[0]) > 3 or abs(pos[1]) > 3 or pos[2] <= 0.1 or distance < 1.0):
        x_rand = random.uniform(-1,1)
        y_rand = random.uniform(-1,1)
        p.resetBaseVelocity(drone, [0, 0, 0], [0, 0, 0])
        p.resetBasePositionAndOrientation(drone, [x_rand, y_rand,1.2+random.choice([-0.5, 0.5])], 
                                          p.getQuaternionFromEuler([np.pi/4,0,np.pi/4]))

    #print(f"{f1}, {f2}, {f3}, {f4}")
    
    # =================== ball behavior ====================
    p.applyExternalForce(ball, -1, [0, 0, balldyninfo[0]*(9.80)], objpos, p.WORLD_FRAME)
    if (abs(objpos[0]) > 3 or abs(objpos[1]) > 3 or objpos[2] > 3 or objpos[2] < 0.1 or distance < 1.0):
        objrand = random.uniform(0, 2)*np.array(random.choice([(1, 1), (1, 0), (0, 1), (0, -1), (-1, 0), (-1, 1), (1, -1), (-1, -1)]))
        p.resetBasePositionAndOrientation(ball, [2,2,2.0], p.getQuaternionFromEuler([0,0,0]))
        objpos, objori = p.getBasePositionAndOrientation(ball) # get position of an moving object

        rho_obj = np.array(pos) - np.array(objpos)
        distance = np.sqrt((pos[0]-objpos[0])**2 + (pos[1]-objpos[1])**2 + (pos[2]-objpos[2])**2)
        obj_dir = rho_obj/distance        
        prev_dir = obj_dir

    # ============= step simulation ==============
    
    p.stepSimulation()
    time.sleep(1./240)
    
# clear connection   
p.disconnect()

print("done!")
