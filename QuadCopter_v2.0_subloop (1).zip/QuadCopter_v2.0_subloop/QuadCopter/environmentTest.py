import pybullet as p
import pybullet_data
import time
import os
import numpy as np
import random
import math
import gym
import quadcopter
from matplotlib import pyplot as plt
from trajqueue import queue
from trajgenerator import trajgenerator 
  



env = gym.make('QuadCopter-v0')
obs = env.reset()



# ###### Quick Trajectory Generator Test #####   

# pitchrr = trajgenerator(0, 1, 0, 0, 0, n=240)


# testlist = []
# timeframe = []
# for i in range(len(pitchrr)):
#     testlist.append(pitchrr.dequeue())
#     timeframe.append(i*1/120)

# print(testlist)
# print(timeframe)

# plt.plot(timeframe, testlist)
# plt.show()


### Main ###

for _ in range(5000):

    setpoints = np.array([random.uniform(-2.0,2.0), random.uniform(-2.0,2.0), random.uniform(-1.0, 1.0)])
    #p.addUserDebugLine([0, 0, 0], setpoints, [1, 0, 0], 3, 0.1)
   
    

    obs, reward, done, _ = env.step(setpoints)
    
    
    if done:
        print("reset")
        env.reset()


