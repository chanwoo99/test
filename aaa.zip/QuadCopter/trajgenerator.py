from trajqueue import queue

def trajgenerator(p, dp, v_d,  angle_d, w_d, g = 9.81, tf = 2.0, height = False, n = 20):
    trajdata = queue(n)
    

    

    if not height:
        a0 = (-120*dp + 60*tf*v_d +12*g*tf**2*angle_d + g*tf**3*w_d)/(6*tf**7)
        a1 = -(-420*dp + 216*tf*v_d + 45*g*tf**2*angle_d + 4*g*tf**3*w_d)/(6*tf**6)
        a2 = (-168*dp + 90*tf*v_d + 20*g*tf**2*angle_d + 2*g*tf**3*w_d)/(2*tf**5)
        a3 = -(-210*dp + 120*tf*v_d + 30*g*tf**2*angle_d + 4*g*tf**3*w_d )/(6*tf**4)
        a4 = g*w_d/6
        a5 = g*angle_d/2
        a6 = v_d
        a7 = p
        #print(f"{a0}, {a1}, {a2}, {a3}, {a4}, {a5}")

    # p(t) = a0*t^7 + a1*t^6 + a2*t^5 + a3*t^4 + a4*t^3 + a5*t^2 + a6*t + a7    
    # v(t) = 7*a0*t^6 + 6*a1*t^5 + 5*a2*t^4 + 4*a3*t^3 + 3*a4*t^2 + 2*a5*t + a6    
    # angle = (1/g)*(7*6*a0*t^5 + 6*5*a1*t^4 + 5*4*a2*t^3 + 4*3*a3*t^2 + 3*2*a4*t + 2*a5)
    # omega = (1/g)*(7*6*5*a0*t^4 + 6*5*4*a1*t^3 + 5*4*3*a2*t^2 + 4*3*2*a3*t + 3*2*a4)
    # omega_dot = (1/g)*(7*6*5*4*a0*t^3 + 6*5*4*3*a1*t^2 + 5*4*3*2*a2*t + 4*3*2*a3)
    
        for i in range(n):
            data = (1/g)*(7*6*5*4*a0*(i*tf/n)**3 + 6*5*4*3*a1*(i*tf/n)**2 + 5*4*3*2*a2*(i*tf/n) + 4*3*2*a3)
            trajdata.enqueue(data)
            
        return trajdata
    
    else:
    
        for i in range(n):
            vz_sp = 0.5*(dp - p)
            az_sp = 0.5*(vz_sp-v_d)
            
            data = g + az_sp
            trajdata.enqueue(data)
        return trajdata