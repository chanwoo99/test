import pybullet as p
import pybullet_data
import numpy as np
import os

class Drone:
      
    def __init__(self, client, pos =[0, 0, 1.0], ori = p.getQuaternionFromEuler([0,0,0])):

        
        self.client = client
        f_name = os.path.join(os.path.expanduser('~'), 'QuadCopter_v2.0_no_subloop', 'QuadCopter', 'drone.urdf')
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        self.drone = p.loadURDF('drone.urdf', pos, ori)
        p.changeDynamics(self.drone, -1, mass=1.313, localInertiaDiagonal=[0.034, 0.034, 0.0418])
        p.changeDynamics(self.drone, 0, mass = 0, localInertiaDiagonal=[0, 0, 0])
        p.changeDynamics(self.drone, 1, mass = 0, localInertiaDiagonal=[0, 0, 0])
        p.changeDynamics(self.drone, 2, mass = 0, localInertiaDiagonal=[0, 0, 0])
        p.changeDynamics(self.drone, 3, mass = 0, localInertiaDiagonal=[0, 0, 0])
        

        
        # get drone's dynamics properties (mass, MOI)
        dronebaseinfo=p.getDynamicsInfo(self.drone, -1) 
        dronelinkinfo1 = p.getDynamicsInfo(self.drone, 0) 
        dronelinkinfo2 = p.getDynamicsInfo(self.drone, 1) 
        dronelinkinfo3 = p.getDynamicsInfo(self.drone, 2) 
        dronelinkinfo4 = p.getDynamicsInfo(self.drone, 3) 

        self.drone_mass = dronebaseinfo[0]+dronelinkinfo1[0]+dronelinkinfo2[0]+dronelinkinfo3[0]+dronelinkinfo4[0]
        self.drone_moi = np.array(dronebaseinfo[2])
        #print(f"drone mass: {self.drone_mass}")
        #dprint(f"drone MOI: \n{self.drone_moi}")
        self.drone_pos, self.drone_ori = p.getBasePositionAndOrientation(self.drone) # get orientation and position of drone
        self.drone_linvel, self.drone_angvel = p.getBaseVelocity(self.drone)
        

        
        
    def get_ids(self):
        return self.client, self.drone
    
    ## TO DO: implement trajectory -> drone dynamics logic ##
    def apply_action(self, action):
        
        #print(action[0])
        torque_x = -self.drone_moi[0]*action[1]
        torque_y = self.drone_moi[1]*action[0]
        thrust = self.drone_mass*action[2]

        if thrust <= 0:
            thrust = self.drone_mass*9.81
        
        # print(f"angular accl: {action[0]}, torque_y:{torque_y}")

        #print(thrust-self.drone_mass*9.81)
        _, drone_ori = p.getBasePositionAndOrientation(self.drone)
        rotmatrix_flat = np.array(p.getMatrixFromQuaternion(drone_ori))
        rotmatrix =  np.reshape(rotmatrix_flat, (3,3)) # rotation of body relative to world
        
        

        p.applyExternalForce(self.drone, -1, np.matmul(rotmatrix,[0, 0, thrust]), self.drone_pos, p.WORLD_FRAME)
        #p.addUserDebugLine([0,0,0], np.matmul(rotmatrix,[0, 0, thrust]), [1, 0, 0], 1.0, 0.05, self.drone)
        p.applyExternalTorque(self.drone, -1, [torque_x, torque_y, 0], p.LINK_FRAME)
        
        
    def get_observation(self):
        self.drone_pos, self.drone_ori = p.getBasePositionAndOrientation(self.drone) # get orientation and position of drone
        self.drone_linvel, self.drone_angvel = p.getBaseVelocity(self.drone)
        
        return self.drone_pos, self.drone_ori, self.drone_linvel, self.drone_angvel
    
    def resetstat(self, pos, ori = p.getQuaternionFromEuler([0,0,0])):
        p.resetBasePositionAndOrientation(self.drone, pos, ori)
        p.resetBaseVelocity(self.drone, [0, 0, 0], [0, 0, 0])
