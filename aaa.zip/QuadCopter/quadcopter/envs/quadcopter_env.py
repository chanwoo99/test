import pybullet as p
import pybullet_data
import time
import os
import numpy as np
import random
import math
import gym
import gym.spaces
from quadcopter.resources.drone import Drone
from quadcopter.resources.object import Object
from gym.utils import seeding
from trajgenerator import trajgenerator
from trajqueue import queue

class QuadCopterEnv(gym.Env):
    #metadata= {'render.modes': ['human']}
    def __init__(self):
        super(QuadCopterEnv, self).__init__()
        
        # Define Action and State Space
        # Action Space (dx, dy, dz)
        self.action_space = gym.spaces.Box(low= np.array([-1.0, -1.0, -1.0]), high = np.array([1.0, 1.0, 1.0]), dtype=np.float32) 
                                           
        
        # Observation Space (should be modified)
        # x, y, z, vx, vy, vz, rotation matrix elements, rr, py, yawr, [Fg], [Fobj], (in euler) roll, pitch, yaw 

        self.observation_space = gym.spaces.Box(low=np.array([-2, -2, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -3, -3, -3, -10, -10, -10, -1000, -1000, -1000, -1000, -1000, -1000, -np.pi, -np.pi, -2*np.pi]),
                                         high=np.array([2, 2, 2.5,  1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 10, 10, 10, 1000, 1000, 1000, 1000, 1000, 1000, np.pi, np.pi, 2*np.pi]), 
                                         dtype=np.float32)
        
        # initialize simulation environment
        ## TO DO ##
        self.client = p.connect(p.DIRECT) # p.GUI if you want to see graphically; otherwise, set p.DIRECT
        p.setGravity(0,0,-9.81)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        planeID = p.loadURDF("plane.urdf") # set up map
        
        
        self.alpha = 0.5
        self.beta = 10.0
        self.safeDistance = 1.5
        self.goal = [0, 0, 1.2]
        self.drone = None
        self.object = None
        self.objspeed = random.uniform(1.0, 2.0)
        self.fixed_dir = None
        self.n_eval = 240 # number of trajectory evaluation steps
        self.n_points = 240 # number of trajectory setpoints
        self.desired_time = 2.0  
        self.c_reward = 0

        p.setTimeStep(1/120, self.client) # ADJUST THIS WHEN CHANGING EVALUATION STEPS 

        print("environment initialized! Please call reset() to start interaction.")
    
    def step(self, action):
        done = False

        ## TRAJECTORY GENERATOR ##
  
        # def trajgenerator(
        # p: current position of drone,
        # dp: given action (displacement),
        # v_d: current velocity of drone,
        # w_d: current angular velocity of drone,
        # angle_d: current angle of drone,
        # g: gravitational acceleration = 9.81,
        # tf: desired total time to reach destination = 2,
        # height: if trajectory is about z-axis = False,
        # n: number of steps of trajectory prediction = 20) 

        # OUTPUT: QUEUE OF N ANGULAR ACCELERATION POINTS OR THRUST

        drone_pos, drone_ori, drone_linvel, drone_angvel = self.drone.get_observation()
        drone_ori_euler = p.getEulerFromQuaternion(drone_ori)

        pitchrr = trajgenerator(drone_pos[0], action[0], 0*drone_linvel[0],  0*drone_ori_euler[0],  0*drone_angvel[0], n=self.n_points)
        rollrr = trajgenerator(drone_pos[1], action[1], 0*drone_linvel[1], 0*drone_ori_euler[1], 0*drone_angvel[1], n=self.n_points)
        thrust = trajgenerator(drone_pos[2], action[2], 0*drone_linvel[2], 0, 0, height=True, n=self.n_points)


        reward = 0

        
        #print(pitchrr._data)
        
        forcetorque = np.array([pitchrr.dequeue(), rollrr.dequeue(), thrust.dequeue()])
        #print(forcetorque)
        # action = dx, dy, dz
        # realize the predicted action, assuming PID very robust
        obj_pos = self.object.get_observation()
        
        self.drone.apply_action(forcetorque)
        p.applyExternalForce(self.object.get_id(), -1, [0, 0, self.object.balldyninfo[0]*(9.80)], obj_pos, p.WORLD_FRAME)
        p.resetBaseVelocity(self.object.get_id(), self.objspeed*self.fixed_dir, [0, 0, 0])
        
        #p.addUserDebugLine(obj_pos, np.array(obj_pos)+np.array(self.fixed_dir), [0, 0, 1], 1.0, 0.05)    
        p.stepSimulation()
        
        time.sleep(1/120) # ADJUST THIS WHEN CHANGING EVALUATION STEPS 


    
        obj_pos = self.object.get_observation()

        drone_pos, drone_ori, drone_linvel, drone_angvel = self.drone.get_observation()
        drone_ori_euler = p.getEulerFromQuaternion(drone_ori)
        rotmatrix_flat = np.array(p.getMatrixFromQuaternion(drone_ori))
        rotmatrix =  np.reshape(rotmatrix_flat, (3,3)) # rotation of body relative to world
        angvel_local = np.matmul(np.linalg.inv(rotmatrix),np.transpose(drone_angvel))
        
        rho_goal = np.array(self.goal)-np.array(drone_pos)
        distance_goal = np.sqrt((drone_pos[0]-self.goal[0])**2 + (drone_pos[1]-self.goal[1])**2 + (drone_pos[2]-self.goal[2])**2)
        goal_dir = rho_goal/distance_goal
        
        rho_obj = np.array(drone_pos) - np.array(obj_pos)
        distance_obj = np.sqrt((drone_pos[0]-obj_pos[0])**2 + (drone_pos[1]-obj_pos[1])**2 + (drone_pos[2]-obj_pos[2])**2)
        obj_dir = rho_obj/distance_obj

        F_goal = self.alpha*distance_goal*goal_dir
        
        if distance_obj <= self.safeDistance:
            F_object = (distance_obj <= self.safeDistance)*(0.5*self.beta*(1/(distance_goal**2))*obj_dir)
        else:
            F_object = [0, 0, 0]

        drone_obs = np.array([drone_pos[0], drone_pos[1], drone_pos[2], 
        rotmatrix_flat[0], rotmatrix_flat[1], rotmatrix_flat[2], 
        rotmatrix_flat[3], rotmatrix_flat[4], rotmatrix_flat[5],
        rotmatrix_flat[6], rotmatrix_flat[7], rotmatrix_flat[8], 
        drone_linvel[0], drone_linvel[2], drone_linvel[2], 
        angvel_local[0], angvel_local[1], angvel_local[2],
        F_goal[0], F_goal[1], F_goal[2],
        F_object[0], F_object[1], F_object[2], drone_ori_euler[0], drone_ori_euler[1], drone_ori_euler[2]], dtype='float32')
        
            #ball reset condition
        if (abs(obj_pos[0]) > 3 or abs(obj_pos[1]) > 3 or obj_pos[2] > 3 or obj_pos[2] < 0.10):            
            obj_pos_x = (2*(random.uniform(0, 1) > 0.5)-1)*2
            obj_pos_y = (2*(random.uniform(0, 1) > 0.5)-1)*2
            obj_pos_z = random.sample([2.0, 0.5], 1)
            obj_pos_z = obj_pos_z[0]
            

            
            self.object.resetbehavior([obj_pos_x, obj_pos_y, obj_pos_z])
            obj_pos = self.object.get_observation()
            drone_pos, _, _, _= self.drone.get_observation()

            rho_obj = np.array(drone_pos) - np.array(obj_pos)
            distance_obj = np.sqrt((drone_pos[0]-obj_pos[0])**2 + (drone_pos[1]-obj_pos[1])**2 + (drone_pos[2]-obj_pos[2])**2)
            obj_dir = rho_obj/distance_obj           
            
            self.fixed_dir = obj_dir  
            self.objspeed = random.uniform(1.0,2.0)           
        
        ##calculate reward##
        
        r_goal = 0
        r_obj = 0
        r_attr = 0
        
        # attitude rate reward
        # r_attr1 = (abs(angvel_local[0])> 2.0)*abs(angvel_local[0]-2.0)/(2.0)
        # r_attr2 = (abs(angvel_local[1])> 2.0)*abs(angvel_local[1]-2.0)/(2.0)
        # r_attr3 = (abs(angvel_local[2])> 2.0)*abs(angvel_local[2]-2.0)/(2.0)
        # r_attr = r_attr1 + r_attr2 + r_attr3
        
        # goal reward
        if (distance_goal <= 0.15):
            r_goal = 1.0
        else:
            r_goal = 0.05/distance_goal
        
        # object reward
        if (distance_obj <= self.safeDistance):
            r_obj = 1.0*distance_obj
        
        reward = 0.5*r_goal + 0.5*r_obj
        

        # termination condi
        if (abs(drone_pos[0]) > 2.0 or abs(drone_pos[1]) > 2.0 or drone_pos[2] > 2.0 or drone_pos[2] < 0.30):
            print("out of bounds")
            reward = reward-200.0
            done = True


        if (abs(drone_ori_euler[0])> 70*np.pi/180 or abs(drone_ori_euler[1])> 70*np.pi/180):
            print("out of angle")
            reward = reward-200.0
            done = True


        if (distance_obj < 0.4):
            print("floor")
            reward = reward-200.0
            done = True

        self.c_reward += reward

            


            
        #print(time.time()-s_time)
        #test info
        info = dict()
        
        # reward cumulation

        
        return drone_obs, reward, done, info

        
    # Reset environment and re-generate
    def reset(self, seed=None, options=None):
        # super().reset(seed=seed)
        p.resetSimulation(self.client)
        p.setGravity(0,0,-9.81)
        self.plane = p.loadURDF("plane.urdf") # set up map
        
        x_d, y_d, z_d = self.randompos()
        self.drone = Drone(self.client, pos=[x_d, y_d, z_d])
        
        # object behavior
        obj_pos_x = (2*(random.uniform(0, 1) > 0.5)-1)*2
        obj_pos_y = (2*(random.uniform(0, 1) > 0.5)-1)*2
        obj_pos_z = random.sample([2.0, 0.5], 1)
        obj_pos_z = obj_pos_z[0]
        
        self.object = Object(self.client, 3, pos=[obj_pos_x, obj_pos_y, obj_pos_z])
        self.goal = [0, 0, 1.2]
        

        
        
        drone_pos, drone_ori, drone_linvel, drone_angvel = self.drone.get_observation()
        drone_ori_euler = p.getEulerFromQuaternion(drone_ori)
        obj_pos = self.object.get_observation()
        rotmatrix_flat = np.array(p.getMatrixFromQuaternion(drone_ori))
        rotmatrix =  np.reshape(rotmatrix_flat, (3,3)) # rotation of body relative to world
        angvel_local = np.matmul(np.linalg.inv(rotmatrix),np.transpose(drone_angvel))
        
        rho_goal = np.array(self.goal)-np.array(drone_pos)
        distance_goal = np.sqrt((drone_pos[0]-self.goal[0])**2 + (drone_pos[1]-self.goal[1])**2 + (drone_pos[2]-self.goal[2])**2)
        goal_dir = rho_goal/distance_goal
        
        rho_obj = np.array(drone_pos) - np.array(obj_pos)
        distance_obj = np.sqrt((drone_pos[0]-obj_pos[0])**2 + (drone_pos[1]-obj_pos[1])**2 + (drone_pos[2]-obj_pos[2])**2)
        obj_dir = rho_obj/distance_obj

        F_goal = self.alpha*distance_goal*goal_dir
        F_object = -0.5*self.beta*(1/(distance_goal**2))*obj_dir
        

    
        self.object.resetbehavior([obj_pos_x, obj_pos_y, obj_pos_z])
        self.fixed_dir = obj_dir


        
        
        drone_obs = [drone_pos[0], drone_pos[1], drone_pos[2], 
        rotmatrix_flat[0], rotmatrix_flat[1], rotmatrix_flat[2], 
        rotmatrix_flat[3], rotmatrix_flat[4], rotmatrix_flat[5],
        rotmatrix_flat[6], rotmatrix_flat[7], rotmatrix_flat[8], 
        drone_linvel[0], drone_linvel[2], drone_linvel[2], 
        angvel_local[0], angvel_local[1], angvel_local[2],
        F_goal[0], F_goal[1], F_goal[2],
        F_object[0], F_object[1], F_object[2], drone_ori_euler[0], drone_ori_euler[1], drone_ori_euler[2]]
        
        self.c_reward = 0        
        print("reset complete")
        info = dict()
        return np.array(drone_obs, dtype='float32')
        
    
    ## TO DO: visualize simulation using p.GUI ##
    def render(self):
        pass
    
    def close(self):
        p.disconnect(self.client)
    
    def seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]
    
    # Generate random position for drone to start
    def randompos(self, min = -2.0, max = 2.0, hmin = 0.30, hmax = 1.5):
        x = random.uniform(min, max)
        y = random.uniform(min, max)
        z = random.uniform(hmin, hmax)
        return x, y, z
    
