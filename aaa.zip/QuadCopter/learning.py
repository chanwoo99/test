import pybullet as p
import pybullet_data
import time
import os
import numpy as np
import random
import math
import gym
import quadcopter
from matplotlib import pyplot as plt
from trajqueue import queue
from trajgenerator import trajgenerator 
from warnings import filterwarnings
filterwarnings(action='ignore', category=DeprecationWarning, message='`np.bool8` is a deprecated alias')

from stable_baselines3 import TD3
from stable_baselines3.common.noise import NormalActionNoise, OrnsteinUhlenbeckActionNoise
from stable_baselines3.td3.policies import MlpPolicy
from stable_baselines3.common.vec_env.subproc_vec_env import SubprocVecEnv
from  stable_baselines3.common.vec_env import vec_extract_dict_obs
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.logger import TensorBoardOutputFormat

# class VecExtractDictObs(VecEnvWrapper):
#     """
#     A vectorized wrapper for filtering a specific key from dictionary observations.
#     Similar to Gym's FilterObservation wrapper:
#         https://github.com/openai/gym/blob/master/gym/wrappers/filter_observation.py

#     :param venv: The vectorized environment
#     :param key: The key of the dictionary observation
#     """

#     def __init__(self, venv: VecEnv, key: str):
#         self.key = key
#         super().__init__(venv=venv, observation_space=venv.observation_space[self.key])

#     def reset(self) -> np.ndarray:
#         obs = self.venv.reset()
#         return obs[self.key]

#     def step_async(self, actions: np.ndarray) -> None:
#         self.venv.step_async(actions)

#     def step_wait(self) -> VecEnvStepReturn:
#         obs, reward, done, info = self.venv.step_wait()
#         return obs[self.key], reward, done, info
    
    
def make_env(env_id, seed):
    def _f():
        env = gym.make(env_id)
        env.seed(seed)
        return env
    return _f


class CumulativeRewardCallback(BaseCallback):
    def __init__(self, verbose = 0):
        super(CumulativeRewardCallback, self).__init__(verbose)
    def _on_step(self) -> bool:
        temp = self.training_env.get_attr('c_reward')
        temp = sum(temp)/len(temp)
        
        self.logger.record('cumulative_reward', temp)
        return True
        
    

### Main ###


if __name__ == "__main__":

    ### Environment Preparation ###

    nproc = 8

    envs = [make_env('QuadCopter-v0', seed) for seed in range(nproc)]
    envs = SubprocVecEnv(envs)

    # envs = vec_extract_dict_obs.VecExtractDictObs(envs, 'observation')
    #env = VecExtractDictObs(env, key="observation")

    obs = envs.reset()
    #print(type(envs.action_space))
    #obs = obs[:, 0]
    # print(obs)

    ### Preset Parameter ###


    t_max = 20000 # maximum episode steps => 10000 or 20000 recommended

    n_actions = 3
    action_noise = NormalActionNoise(np.zeros(n_actions), sigma=0.1 * np.ones(n_actions))
    model = TD3("MlpPolicy", envs, train_freq=1, action_noise=action_noise, verbose = 2, tensorboard_log="./td3_quadcopter_tb/",device='cpu')
    model.learn(total_timesteps=1000000, callback=CumulativeRewardCallback(), log_interval=10, tb_log_name='20230526_1')
    model.save("td3_quadcopter")
 
    model = TD3.load("td3_quadcopter")
    
    
    for i in range(t_max):
        
        action, _states = model.predict(obs)
        
        obs, reward, done, info = envs.step(action)
            # if done:
            #     print("reset")
            #     envs.reset()
        #print(f"End of subloop. time elapsed: {time.time()-s_time}")
        
    # clear connection   
    # p.disconnect()

    print("done!")
