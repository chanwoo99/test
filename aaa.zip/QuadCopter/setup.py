from setuptools import setup

setup(
    name="quadcopter",
    version='0.0.1',
    install_requires=['gym', 'pybullet', 'numpy', 'matplotlib']
    
)