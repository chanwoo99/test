class queue:
    def __init__(self, n):
        self._data = [None]*n
        self._size = 0
        self._front = 0
    
    def __len__(self):
        return self._size
    
    def is_empty(self):
        return self._size == 0
    
    def first(self):
        if self.is_empty():
            raise IndexError("Queue is Empty")
        return self._data[self._front] 
    
    def dequeue(self):
        if self.is_empty():
            return 0
        answer = self._data[self._front]
        self._data[self._front] = None
        self._front = (self._front +1) % len(self._data)
        self._size -= 1
        return answer
    
    def enqueue(self, e):
        if self._size == len(self._data):
            raise IndexError("Queue Full")
        avail = (self._front+self._size) % len(self._data)
        self._data[avail] = e
        self._size += 1